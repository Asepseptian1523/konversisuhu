/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package konversi;

/**
 *
 * @author Ricky Hr
 */
public class calcius {
    public double toCalvin(double n){
        double k;
        k = n +273.15;
        return k ;
    }public double toFahrenheit(double n){
        double k;
        k = n *1.8+32;
        return k ;
    }public double toCelcius(double n){
        double k;
        k = n;
        return k ;
    }
    
    
    
}
